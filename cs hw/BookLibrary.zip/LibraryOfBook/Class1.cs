﻿namespace LibraryOfBook
{
    public class Class1
    {

    }
}
