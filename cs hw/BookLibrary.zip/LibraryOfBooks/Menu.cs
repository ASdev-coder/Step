﻿namespace LibraryOfBooks;
using SerializerDeserializer;
using Book;
using static System.Reflection.Metadata.BlobBuilder;

public static class Menu
{
    public static BookLibrary library = new BookLibrary();

    public static List<string> actions = new List<string>() 
    { 
        "Добавить книгу", 
        "Просмотреть книги", 
        "Найти книгу", 
        "Удалить книгу", 
        "Выйти" 
    };

    public static void Start()
    {
        SerializerDeserializer.DeserializeBooksFromFile(library.FilePath, library.Books);

        Console.WriteLine("Добро пожаловать в библиотеку!");
        int choice;

        do
        {
            choice = MenuChoice();

            switch (choice)
            {
                case 1:
                    library.AddBook();
                    break;
                case 2:
                    library.ShowBooks();
                    break;
                case 3:
                    library.FoundBook();
                    break;
                case 4:
                    library.RemoveBook();
                    break;
                case 5:
                    return;
                default:
                    Console.WriteLine("Не правильный выбор, выберите корректный!");
                    break;
            }
        } while (choice != 5);
    }

    static int MenuChoice()
    {
        Console.WriteLine("\nВыберите действие: \n");
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"{i + 1}. {actions[i]}");
        }

        Console.Write("Ваш выбор: ");
        int choice = Convert.ToInt32(Console.ReadLine());

        return choice;
    }

}
