﻿namespace SerializerDeserializer
{
    using System.Text.Json;
    using Book;

    public static class SerializerDeserializer
    {
        public static void SerializeBooks(string filePath, List<Book> library)
        {
            string json;

            try
            {
                json = JsonSerializer.Serialize(library); //сериализуем нашу библиотеку с книгами в json
                File.WriteAllText(filePath, json);  //создает файл и записывает туда текст формата json по пути, который мы задали (filePath)
                Console.WriteLine($"Данные сохранены в файл: {filePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении: {ex.Message}");
            }
        }

        public static void DeserializeBooksFromFile(string filePath, List<Book> library)
        {
            try
            {
                if (File.Exists(filePath)) // Проверка на то, существует ли файл
                {
                    string json = File.ReadAllText(filePath); // Читаем и записываем содержимое файла в (string json)
                    var deserializedBooks = JsonSerializer.Deserialize<List<Book>>(json); // Десериализуем в список книг

                    if (deserializedBooks != null)
                    {
                        library.Clear();
                        library.AddRange(deserializedBooks); //в library перекидываем содержимое deserializedBooks
                    }
                }
                else
                {
                    Console.WriteLine("Файл с библиотекой не найден. Будет создан новый.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при десериализации: {ex.Message}");
            }
        }
    }
}
