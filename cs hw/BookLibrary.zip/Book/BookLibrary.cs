﻿namespace Book;
using SerializerDeserializer;


public class BookLibrary
{
    private const string libraryFile = "bookLibrary.json";
    private string filePath = @$"C:\Users\antsk\source\repos\BookLibrary\LibraryOfBooks\data\{libraryFile}";
    private List<Book> books = new List<Book>();

    public void AddBook()
    {
        Console.WriteLine($"\n---Добавление книги в библиотеку---\n");
        Book book = Book.CreateBook();

        foreach (var b in books)
        {
            if (b.Title == book.Title && b.Author == book.Author)
            {
                Console.WriteLine($"\nКнига под названием \"{book.Title}\" уже есть в библиотеке\n");
                return;
            }
        }

        books.Add(book);
        Console.WriteLine($"\nКнига под названием \"{book.Title}\" была добавлена в библиотеку.\n");
        SerializerDeserializer.SerializeBooks(filePath, books);
    }

    public void RemoveBook()
    {
        Console.WriteLine("Введите название книги для удаления: ");
        string removeTitle = Console.ReadLine();

        for (int i = 0; i < books.Count; i++)
        {
            if (books[i].Title == removeTitle)
            {
                Console.WriteLine($"\nКнига под названием \"{books[i].Title}\" была удалена из библиотеки...\n");
                books.RemoveAt(i);  //метод для листа "удаление элемента по индексу"
                SerializerDeserializer.SerializeBooks(filePath, books);
                return;
            }
        }

        Console.WriteLine($"\nКнига под названием \"{removeTitle}\" не найдена в библиотеке...\n");
    }

    public void ShowBooks()
    {
        if (books.Count == 0)
        {
            Console.WriteLine("\nБиблиотека пуста.\n");
        }
        else
        {
            Console.WriteLine("\nКниги в библиотеке: \n");
            foreach (var book in books)
            {
                book.ShowInfo();
            }
        }
    }

    public void FoundBook()
    {
        Console.WriteLine("Введите название книги: ");
        string foundTitle = Console.ReadLine();
        Console.WriteLine("Введите автора книги: ");
        string foundAuthor = Console.ReadLine();

        var book = books.FirstOrDefault(b => b.Title == foundTitle && b.Author == foundAuthor); // FirstOrDefault метод для List, найти первый по условии или вернуть дэфолт типа
        if (book != null)
        {
            Console.WriteLine($"\nКнига под названием \"{book.Title}\" автором {book.Author} найдена!\n");
        }
        else
        {
            Console.WriteLine($"\nКнига под названием \"{foundTitle}\" автором {foundAuthor} не найдена.\n");
        }
    }

    public List<Book> Books => books;
    public string FilePath => filePath;
}
