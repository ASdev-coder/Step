﻿using System;

namespace Book
{
    public class Book
    {

        public Book() { }

        public Book(string title, string genre, short age, string author)
        {
            Title = title;
            Genre = genre;
            Age = age;
            Author = author;
        }

        public static Book CreateBook()
        {
            Console.Write($"Введите название книги => ");
            string title = Console.ReadLine();

            Console.Write($"Введите автора книги => ");
            string author = Console.ReadLine();

            Console.Write($"Введите жанр книги => ");
            string genre = Console.ReadLine();

            Console.Write($"Введите дату написания книги => ");
            short age = Convert.ToInt16(Console.ReadLine());

            return new Book(title, genre, age, author);
        }

        public void ShowInfo()
        {
            Console.WriteLine($"\"{Title}\", {Author}, {Genre}, {Age} ");
        }

        public string Author { get; set; }
        public string Title { get; set; }
        public int Age { get; set; }
        public string Genre { get; set; }
    }
}
