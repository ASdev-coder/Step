﻿namespace BookLibrary;
using Book;

internal class Program
{
    static void Main(string[] args)
    {
        Book book = new Book("ada", "fsdf", 12, "23");
        book.showInfo();
    }
}
