﻿namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a num of rows to two-dimensional array: ");
            ushort rows = Convert.ToUInt16(Console.ReadLine());
            Console.WriteLine("Enter a num of columns to two-dimensional array: ");
            ushort columns = Convert.ToUInt16(Console.ReadLine());
            Console.WriteLine("Your Array:");

            ushort[,] array = new ushort[rows, columns];

            Random random = new Random();

            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    array[i , j] = Convert.ToUInt16(random.Next(1,10));
                    Console.Write($"{array[i, j]}\t");
                }

                Console.WriteLine();
            }

            if(columns >= 2)
            {
                Console.WriteLine("U can swap 2 columns...Enter which one u want swap: ");

                ushort first = Convert.ToUInt16(Convert.ToInt32(Console.ReadLine())-1);
                ushort second = Convert.ToUInt16(Convert.ToInt32(Console.ReadLine()) - 1);

                for (int i = 0; i < rows; i++)
                {
                    ushort firstSwapper = array[i, first];
                    ushort secondSwapper = array[i, second];

                    for (int j = 0; j < columns; j++)
                    {

                        array[i , second] = firstSwapper;
                        array[i, first] = secondSwapper;

                        Console.Write($"{array[i, j]}\t");
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
