﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter size of array: ");
        int size = Convert.ToInt32(Console.ReadLine());
        int sizeOfEvenArray = 0;
        int sizeOfOddArray = 0;

        int[] array = new int[size];

        Random random = new Random();


        for (int i = 0; i < size; ++i)
        {
            array[i] = random.Next(10,100);

            if (array[i] % 2 == 0)
            {
                sizeOfEvenArray ++;
            }
        }

        sizeOfOddArray = size - sizeOfEvenArray;


        int[] evenNumbersArray = new int[sizeOfEvenArray];
        int[] oddNumbersArray = new int[sizeOfOddArray];
        int evenIterator = 0;
        int oddIterator = 0;

        for (int i = 0; i < size; ++i)
        {
            if (array[i] % 2 == 0)
            {
                evenNumbersArray[evenIterator] = array[i];
                evenIterator++;
            }
            else
            {
                oddNumbersArray[oddIterator] = array[i];
                oddIterator++;
            }
        }

        Console.Write("Array - ");
        for (int i = 0; i < size; ++i)
            Console.Write($"{array[i]} ");

        Console.Write("\nEven Numbers Array - ");
        for (int i = 0; i < sizeOfEvenArray; ++i)
            Console.Write($"{evenNumbersArray[i]} ");

        Console.Write("\nOdd Numbers Array - ");
        for (int i = 0; i < sizeOfOddArray; ++i)
            Console.Write($"{oddNumbersArray[i]} ");

        Console.Write("\n\n\n\n\n\n");

    }
}
